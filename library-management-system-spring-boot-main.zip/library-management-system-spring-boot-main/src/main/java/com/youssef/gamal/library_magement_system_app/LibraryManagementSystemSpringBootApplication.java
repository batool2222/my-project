package com.youssef.gamal.library_magement_system_app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LibraryManagementSystemSpringBootApplication {

    public static void main(String[] args) {
        SpringApplication.run(LibraryManagementSystemSpringBootApplication.class, args);
    }

}
