package com.youssef.gamal.library_magement_system_app;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LibraryManagementSystemSpringBootApplicationTests {

    @Test
    void contextLoads() {
    }

}
